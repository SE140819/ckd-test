export const Introduction = {
    title: 'Chào Quý khách hàng thân thiết yêu của Blue Pink',
    content:
        ' Tôi là Phan Thị Phương Tiền, người sáng tạo của Công Ty TNHH Blue Pink - nơi chúng tôi mang đến sự hòa quyện giữa vẻ đẹp tự nhiên và khoa học trong lĩnh vực mỹ phẩm.',
    position: 'Giám đốc',
};