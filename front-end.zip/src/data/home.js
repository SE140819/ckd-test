
export const product_list = [
    {
        id: 1,
        name: 'Bộ Chăm Sóc Da Toàn Diện Limited  -  Xuân Rực Rỡ , Full Quà Tặng Giới Hạn 100 hộp duy nhất',
        price: 329000,
        voucher: 50,
        image: 'https://ckdvietnam.com/upload/product/combo-tet-ckd-2-4794.webp',
    },
    {
        id: 2,
        name: 'Bộ Chăm Sóc Da Toàn Diện Limited  -  Xuân Rực Rỡ , Full Quà Tặng Giới Hạn 100 hộp duy nhất',
        price: 329000,
        voucher: 10,
        image: 'https://ckdvietnam.com/upload/product/combo-tet-ckd-2-4794.webp',
    },
    {
        id: 3,
        name: 'Bộ Chăm Sóc Da Toàn Diện Limited  -  Xuân Rực Rỡ , Full Quà Tặng Giới Hạn 100 hộp duy nhất',
        price: 329000,
        voucher: 10,
        image: 'https://ckdvietnam.com/upload/product/combo-tet-ckd-2-4794.webp',
    },

    {
        id: 4,
        name: 'Bộ Chăm Sóc Da Toàn Diện Limited  -  Xuân Rực Rỡ , Full Quà Tặng Giới Hạn 100 hộp duy nhất',
        price: 329000,
        voucher: 10,
        image: 'https://ckdvietnam.com/upload/product/combo-tet-ckd-2-4794.webp',
    },
    {
        id: 5,
        name: 'Bộ Chăm Sóc Da Toàn Diện Limited  -  Xuân Rực Rỡ , Full Quà Tặng Giới Hạn 100 hộp duy nhất',
        price: 329000,

        image: 'https://ckdvietnam.com/upload/product/combo-tet-ckd-2-4794.webp',
    },
]; 

export const review = [
    {
        id: 1,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz50235689895375d9b2cab8cfcb2f95d42404b3af92819-6977.webp',
        customer: 'Kim Ngân',
        rating: 1.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 2,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Ngưu',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 3,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz50234679626169c45d8aa93e718c970538e3e4a8aef9d-2969.webp',
        customer: 'Kim Bạc',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 4,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Y',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 5,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Y',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },

    {
        id: 7,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Y',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 8,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Y',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 9,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Y',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 10,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Y',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
    {
        id: 11,
        img: 'https://ckdvietnam.com/upload/news/anyconvcomz5023568994442bf949dc10a3105bdb0e856692d67f328-6618.webp',
        customer: 'Kim Y',
        rating: 4.5,
        date: '2021-10-10',
        feedback:
            'em toner này giúp thu nhỏ lỗ chân lông của tui hẳn ra luôn á, da cũng sáng và mịn hơn sau mỗi lần sử dụng luôn, rất hài lòng, lần sau sẽ ủng hộ tiếp.',
    },
];

export const title = {
    sanphamkhuyenmai: 'Sản phẩm khuyến mãi',
    danhgia: 'Đánh giá',
    video: 'Video',
    Tab1: 'TỐT NHẤT',
    Tab2: 'MỚI NHẤT',
    daban: 'Đã bán:',
    xemthem: 'Xem thêm',
    reviewkhachhang: ' CÁC ĐÁNH GIÁ KHÁC VỀ SẢN PHẨM NÀY',
    ngaydanhgia: 'Ngày đánh giá: ',
};