export const contact = {
    company: 'CÔNG TY TNHH BLUEPINK',
    address: 'Địa chỉ: 97/9 đường Phạm Thái Bường, phường Tân Phong, Q7, TP.Hồ Chí Minh',
    hotline: 'Hotline: 0975 155 503',
    zalo: '0975 155 503',
    mail: ' bluepink@ckdcosvietnam.com',
    mst: '0317392099',
    issued: 'Sở Kế Hoạch Đầu Tư TP.Hồ Chí Minh',
};