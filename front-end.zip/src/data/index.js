import { products, promotions } from './shopping';

export default {
    products,
    promotions,
};

    