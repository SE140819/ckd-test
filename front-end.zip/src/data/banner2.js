export const banner = [
    {
        title: 'Bộ Chăm Sóc Da Toàn Diện Limited  -  Xuân Rực Rỡ , Full Quà Tặng Giới Hạn 100 hộp duy nhất',
        url: 'https://ckdvietnam.com/san-pham/tinh-chat-mo-tham-sang-da-ckd-vita-c-teca-7-days-4g',
        img: 'https://ckdvietnam.com/upload/photo/anyconvcombanner-vit-c-9453.webp',
    },
    {
        title: 'Bộ Chăm Sóc Da Toàn Diện Limited  -  Xuân Rực Rỡ , Full Quà Tặng Giới Hạn 100 hộp duy nhất',
        url: 'https://ckdcosvietnam.com/san-pham/khuyen-mai"',
        img: 'https://ckdvietnam.com/upload/photo/anyconvcombanner-web-pc-9456.webp',
    },
];
